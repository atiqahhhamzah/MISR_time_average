INVENTORY

These examples operate on a file called inventory.hdf.  They do the following:


inventory_1-1.py:
Opens the file inventory.hdf (creating it if it doesn't exist), and adds a VData set of inventory items to it.

inventory_1-2.py:
Opens the file inventory.hdf (creating it if it doesn't exist) storing VData, updates the "status" attribute, and updates the data.

inventory_1-3.py:
Opens the file inventory.hdf (creating it if it doesn't exist) storing VData, updates the "status" attribute, and updates the data.

inventory_1-4.py:
Opens the file inventory.hdf (which must already exist) and displays some of its data.

inventory_1-5.py:
Similar functionality to inventory_1-5.py

TODO: Better documentation
